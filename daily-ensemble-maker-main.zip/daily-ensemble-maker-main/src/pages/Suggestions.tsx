import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import AppLayout from '@/components/AppLayout';
import { Lightbulb } from 'lucide-react';

type WardrobeItem = { id: string; name: string; type: string; color: string; season: string; image_url: string | null; };

const colorCompatibility: Record<string, string[]> = {
  black: ['white', 'grey', 'beige', 'red', 'navy', 'pink', 'yellow'],
  white: ['black', 'navy', 'blue', 'grey', 'beige', 'red', 'green'],
  navy: ['white', 'beige', 'grey', 'brown', 'pink', 'yellow'],
  grey: ['black', 'white', 'navy', 'blue', 'pink', 'red'],
  beige: ['black', 'navy', 'brown', 'white', 'green', 'blue'],
  brown: ['beige', 'white', 'navy', 'green', 'orange'],
  red: ['black', 'white', 'grey', 'navy', 'beige'],
  blue: ['white', 'grey', 'beige', 'brown', 'navy'],
  green: ['white', 'beige', 'brown', 'navy', 'grey'],
  pink: ['black', 'white', 'grey', 'navy', 'beige'],
  yellow: ['black', 'navy', 'white', 'grey', 'blue'],
  orange: ['brown', 'navy', 'white', 'beige', 'black'],
  purple: ['white', 'grey', 'beige', 'black', 'pink'],
};

const colorMap: Record<string, string> = {
  black: '#1a1a1a', white: '#f5f5f5', navy: '#1a2744', grey: '#808080', beige: '#d4b896',
  brown: '#6b4226', red: '#c0392b', blue: '#2980b9', green: '#27ae60', pink: '#e84393',
  yellow: '#f1c40f', orange: '#e67e22', purple: '#8e44ad',
};

const Suggestions = () => {
  const { user } = useAuth();
  const [items, setItems] = useState<WardrobeItem[]>([]);

  useEffect(() => {
    if (!user) return;
    const fetch = async () => {
      const { data } = await supabase
        .from('wardrobe_items')
        .select('id, name, type, color, season, image_url')
        .eq('user_id', user.id);
      setItems((data as WardrobeItem[]) ?? []);
    };
    fetch();
  }, [user]);

  // Generate matching suggestions: for each item, find all compatible items
  const suggestions = items.flatMap(item => {
    const compatible = colorCompatibility[item.color] || [];
    const matches = items.filter(
      other => other.id !== item.id && compatible.includes(other.color) && other.type !== item.type
    );
    return matches.map(match => ({
      item1: item,
      item2: match,
      key: [item.id, match.id].sort().join('-'),
    }));
  });

  // Deduplicate
  const seen = new Set<string>();
  const uniqueSuggestions = suggestions.filter(s => {
    if (seen.has(s.key)) return false;
    seen.add(s.key);
    return true;
  });

  // Group by item
  const groupedByItem = items.map(item => ({
    item,
    matches: uniqueSuggestions
      .filter(s => s.item1.id === item.id || s.item2.id === item.id)
      .map(s => (s.item1.id === item.id ? s.item2 : s.item1)),
  })).filter(g => g.matches.length > 0);

  return (
    <AppLayout>
      <div className="space-y-6 animate-fade-in">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground">Outfit Suggestions</h1>
          <p className="text-muted-foreground">Discover which pieces in your wardrobe pair well together</p>
        </div>

        {groupedByItem.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground">
            <Lightbulb className="w-12 h-12 mx-auto mb-4 opacity-40" />
            <p className="font-display text-xl mb-2">No suggestions yet</p>
            <p className="text-sm">Add more items to your wardrobe to see outfit suggestions.</p>
          </div>
        ) : (
          <div className="space-y-6">
            {groupedByItem.slice(0, 12).map(({ item, matches }) => (
              <div key={item.id} className="glass-card rounded-xl p-5">
                <div className="flex items-center gap-3 mb-4">
                  {item.image_url ? (
                    <img src={item.image_url} alt={item.name} className="w-12 h-12 rounded-lg object-cover" />
                  ) : (
                    <div className="w-12 h-12 rounded-lg" style={{ backgroundColor: colorMap[item.color] || '#808080' }} />
                  )}
                  <div>
                    <h3 className="font-display font-semibold text-foreground">{item.name}</h3>
                    <p className="text-xs text-muted-foreground capitalize">{item.type} · {item.color}</p>
                  </div>
                  <span className="ml-auto text-xs text-primary font-medium">Pairs with {matches.length} items</span>
                </div>
                <div className="flex gap-2 flex-wrap">
                  {matches.slice(0, 6).map(match => (
                    <div key={match.id} className="flex items-center gap-2 px-3 py-2 rounded-lg bg-secondary text-sm">
                      {match.image_url ? (
                        <img src={match.image_url} alt={match.name} className="w-6 h-6 rounded object-cover" />
                      ) : (
                        <div className="w-6 h-6 rounded" style={{ backgroundColor: colorMap[match.color] || '#808080' }} />
                      )}
                      <span className="text-foreground truncate max-w-[120px]">{match.name}</span>
                      <span className="text-xs text-muted-foreground capitalize">({match.type})</span>
                    </div>
                  ))}
                  {matches.length > 6 && (
                    <span className="text-xs text-muted-foreground self-center">+{matches.length - 6} more</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default Suggestions;
