import { useEffect, useState, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import AppLayout from '@/components/AppLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Camera, Upload, Save } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const SKIN_TONES = [
  { label: 'Fair', value: 'fair', hex: '#FDEBD0' },
  { label: 'Light', value: 'light', hex: '#F5CBA7' },
  { label: 'Medium', value: 'medium', hex: '#E0A96D' },
  { label: 'Olive', value: 'olive', hex: '#C4A265' },
  { label: 'Brown', value: 'brown', hex: '#A0522D' },
  { label: 'Dark', value: 'dark', hex: '#6B3A2A' },
];

const SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL'];

const Profile = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [name, setName] = useState('');
  const [gender, setGender] = useState('');
  const [age, setAge] = useState('');
  const [clothingSize, setClothingSize] = useState('');
  const [skinTone, setSkinTone] = useState('');
  const [skinTonePhotoUrl, setSkinTonePhotoUrl] = useState<string | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!user) return;
    const fetchProfile = async () => {
      const { data } = await supabase
        .from('profiles')
        .select('name, gender, age, clothing_size, skin_tone, skin_tone_photo_url')
        .eq('user_id', user.id)
        .maybeSingle();
      if (data) {
        setName(data.name || '');
        setGender(data.gender || '');
        setAge(data.age?.toString() || '');
        setClothingSize(data.clothing_size || '');
        setSkinTone(data.skin_tone || '');
        setSkinTonePhotoUrl(data.skin_tone_photo_url || null);
        if (data.skin_tone_photo_url) setPhotoPreview(data.skin_tone_photo_url);
      }
    };
    fetchProfile();
  }, [user]);

  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: 'File too large', description: 'Please select an image under 5MB.', variant: 'destructive' });
      return;
    }
    const reader = new FileReader();
    reader.onloadend = () => setPhotoPreview(reader.result as string);
    reader.readAsDataURL(file);

    const ext = file.name.split('.').pop();
    const path = `${user.id}/skin-tone.${ext}`;
    const { error } = await supabase.storage.from('wardrobe-images').upload(path, file, { upsert: true });
    if (error) {
      toast({ title: 'Upload failed', description: error.message, variant: 'destructive' });
      return;
    }
    const { data: urlData } = supabase.storage.from('wardrobe-images').getPublicUrl(path);
    setSkinTonePhotoUrl(urlData.publicUrl);
    toast({ title: 'Photo uploaded!' });
  };

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase
      .from('profiles')
      .update({
        name: name || null,
        gender: gender || null,
        age: age ? parseInt(age) : null,
        clothing_size: clothingSize || null,
        skin_tone: skinTone || null,
        skin_tone_photo_url: skinTonePhotoUrl,
      })
      .eq('user_id', user.id);

    if (error) toast({ title: 'Error', description: error.message, variant: 'destructive' });
    else toast({ title: 'Profile saved!', description: 'Your details have been updated.' });
    setSaving(false);
  };

  return (
    <AppLayout>
      <div className="space-y-8 animate-fade-in max-w-2xl">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground">My Profile</h1>
          <p className="text-muted-foreground">Personalize your StyleVault experience</p>
        </div>

        {/* Skin Tone Photo */}
        <div className="glass-card rounded-xl p-6">
          <h2 className="font-display text-lg font-semibold text-foreground mb-4">Skin Tone Detection</h2>
          <p className="text-sm text-muted-foreground mb-4">Upload a selfie so we can suggest colors that complement your skin tone.</p>
          <div className="flex items-start gap-6">
            <div className="flex-shrink-0">
              <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handlePhotoSelect} />
              <input ref={cameraInputRef} type="file" accept="image/*" capture="user" className="hidden" onChange={handlePhotoSelect} />
              {photoPreview ? (
                <div className="w-32 h-32 rounded-full overflow-hidden border-2 border-primary/30">
                  <img src={photoPreview} alt="Skin tone" className="w-full h-full object-cover" />
                </div>
              ) : (
                <div className="w-32 h-32 rounded-full bg-secondary flex items-center justify-center border-2 border-dashed border-border">
                  <Camera className="w-8 h-8 text-muted-foreground" />
                </div>
              )}
            </div>
            <div className="flex flex-col gap-2">
              <Button variant="outline" size="sm" onClick={() => cameraInputRef.current?.click()}>
                <Camera className="w-4 h-4 mr-2" /> Take Selfie
              </Button>
              <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
                <Upload className="w-4 h-4 mr-2" /> Upload Photo
              </Button>
            </div>
          </div>

          {/* Skin tone selector */}
          <div className="mt-4">
            <Label className="mb-2 block">Or select your skin tone</Label>
            <div className="flex gap-2 flex-wrap">
              {SKIN_TONES.map(tone => (
                <button
                  key={tone.value}
                  onClick={() => setSkinTone(tone.value)}
                  className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-all ${
                    skinTone === tone.value ? 'ring-2 ring-primary bg-primary/10' : 'hover:bg-secondary'
                  }`}
                >
                  <div className="w-10 h-10 rounded-full border border-border" style={{ backgroundColor: tone.hex }} />
                  <span className="text-xs text-muted-foreground">{tone.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Personal Details */}
        <div className="glass-card rounded-xl p-6 space-y-4">
          <h2 className="font-display text-lg font-semibold text-foreground">Personal Details</h2>

          <div className="space-y-2">
            <Label>Display Name</Label>
            <Input value={name} onChange={e => setName(e.target.value)} placeholder="Your name" className="bg-secondary" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Gender</Label>
              <Select value={gender} onValueChange={setGender}>
                <SelectTrigger className="bg-secondary"><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="men">Men</SelectItem>
                  <SelectItem value="women">Women</SelectItem>
                  <SelectItem value="unisex">Non-binary / Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Age</Label>
              <Input type="number" min={10} max={120} value={age} onChange={e => setAge(e.target.value)} placeholder="25" className="bg-secondary" />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Clothing Size</Label>
            <Select value={clothingSize} onValueChange={setClothingSize}>
              <SelectTrigger className="bg-secondary"><SelectValue placeholder="Select size" /></SelectTrigger>
              <SelectContent>
                {SIZES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button onClick={handleSave} disabled={saving} className="bg-gradient-gold text-primary-foreground shadow-gold">
          <Save className="w-4 h-4 mr-2" /> {saving ? 'Saving...' : 'Save Profile'}
        </Button>
      </div>
    </AppLayout>
  );
};

export default Profile;
