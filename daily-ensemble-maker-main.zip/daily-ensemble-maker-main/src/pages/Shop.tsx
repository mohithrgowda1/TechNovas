import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import AppLayout from '@/components/AppLayout';
import { ExternalLink } from 'lucide-react';

type WardrobeItem = { id: string; color: string; season: string; type: string; };

const getCurrentSeason = () => {
  const month = new Date().getMonth();
  if (month >= 2 && month <= 4) return 'spring';
  if (month >= 5 && month <= 7) return 'summer';
  if (month >= 8 && month <= 10) return 'fall';
  return 'winter';
};

const recommendations = [
  { name: 'Classic White Tee', type: 'top', color: 'white', season: 'all', price: '$25', store: 'Uniqlo', url: 'https://www.uniqlo.com', tags: ['essential', 'versatile'], gender: 'unisex', image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=300&h=300&fit=crop' },
  { name: 'Slim Dark Jeans', type: 'bottom', color: 'navy', season: 'all', price: '$50', store: "Levi's", url: 'https://www.levis.com', tags: ['classic', 'everyday'], gender: 'unisex', image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?w=300&h=300&fit=crop' },
  { name: 'Wool Overcoat', type: 'outerwear', color: 'beige', season: 'winter', price: '$180', store: 'Zara', url: 'https://www.zara.com', tags: ['winter', 'luxury'], gender: 'unisex', image: 'https://images.unsplash.com/photo-1539533018447-63fcce2678e3?w=300&h=300&fit=crop' },
  { name: 'Linen Shirt', type: 'top', color: 'beige', season: 'summer', price: '$45', store: 'H&M', url: 'https://www.hm.com', tags: ['summer', 'breathable'], gender: 'men', image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=300&h=300&fit=crop' },
  { name: 'Chino Shorts', type: 'bottom', color: 'beige', season: 'summer', price: '$35', store: 'GAP', url: 'https://www.gap.com', tags: ['summer', 'casual'], gender: 'men', image: 'https://images.unsplash.com/photo-1591195853828-11db59a44f6b?w=300&h=300&fit=crop' },
  { name: 'Leather Boots', type: 'shoes', color: 'brown', season: 'fall', price: '$120', store: 'Dr. Martens', url: 'https://www.drmartens.com', tags: ['fall', 'durable'], gender: 'unisex', image: 'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?w=300&h=300&fit=crop' },
  { name: 'Cashmere Sweater', type: 'top', color: 'grey', season: 'winter', price: '$90', store: 'COS', url: 'https://www.cos.com', tags: ['winter', 'luxury'], gender: 'unisex', image: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=300&h=300&fit=crop' },
  { name: 'Canvas Sneakers', type: 'shoes', color: 'white', season: 'all', price: '$65', store: 'Converse', url: 'https://www.converse.com', tags: ['casual', 'versatile'], gender: 'unisex', image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=300&h=300&fit=crop' },
  { name: 'Trench Coat', type: 'outerwear', color: 'beige', season: 'spring', price: '$150', store: 'Mango', url: 'https://www.mango.com', tags: ['spring', 'classic'], gender: 'women', image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=300&h=300&fit=crop' },
  { name: 'Floral Dress', type: 'dress', color: 'pink', season: 'spring', price: '$55', store: 'ASOS', url: 'https://www.asos.com', tags: ['spring', 'trendy'], gender: 'women', image: 'https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=300&h=300&fit=crop' },
  { name: 'Formal Blazer', type: 'formal', color: 'navy', season: 'all', price: '$130', store: 'Hugo Boss', url: 'https://www.hugoboss.com', tags: ['formal', 'office'], gender: 'men', image: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=300&h=300&fit=crop' },
  { name: 'Silk Scarf', type: 'accessory', color: 'red', season: 'all', price: '$40', store: 'Massimo Dutti', url: 'https://www.massimodutti.com', tags: ['accessory', 'elegant'], gender: 'unisex', image: 'https://images.unsplash.com/photo-1601924638867-3a6de6b7a500?w=300&h=300&fit=crop' },
];

const colorCompat: Record<string, string[]> = {
  black: ['white', 'grey', 'beige', 'red', 'navy'],
  white: ['black', 'navy', 'blue', 'grey', 'beige'],
  navy: ['white', 'beige', 'grey', 'brown', 'pink'],
  grey: ['black', 'white', 'navy', 'blue', 'pink'],
  beige: ['black', 'navy', 'brown', 'white', 'green'],
  brown: ['beige', 'white', 'navy', 'green'],
  red: ['black', 'white', 'grey', 'navy'],
  blue: ['white', 'grey', 'beige', 'brown'],
  green: ['white', 'beige', 'brown', 'navy'],
  pink: ['black', 'white', 'grey', 'navy'],
  yellow: ['black', 'navy', 'white'],
  orange: ['brown', 'navy', 'white'],
  purple: ['white', 'grey', 'beige'],
};

const Shop = () => {
  const { user } = useAuth();
  const [wardrobeItems, setWardrobeItems] = useState<WardrobeItem[]>([]);
  const [filter, setFilter] = useState<'all' | 'season' | 'compatible'>('all');
  const [gender, setGender] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    const fetchData = async () => {
      const { data } = await supabase.from('wardrobe_items').select('id, color, season, type').eq('user_id', user.id);
      setWardrobeItems((data as WardrobeItem[]) ?? []);
      const { data: profile } = await supabase.from('profiles').select('gender').eq('user_id', user.id).maybeSingle();
      setGender(profile?.gender || null);
    };
    fetchData();
  }, [user]);

  const season = getCurrentSeason();
  const userColors = [...new Set(wardrobeItems.map(i => i.color))];
  const compatibleColors = new Set(userColors.flatMap(c => colorCompat[c] || []));

  let filtered = recommendations;
  // Filter by gender
  if (gender && gender !== 'unisex') {
    filtered = filtered.filter(r => r.gender === gender || r.gender === 'unisex');
  }
  if (filter === 'season') filtered = filtered.filter(r => r.season === season || r.season === 'all');
  if (filter === 'compatible') filtered = filtered.filter(r => compatibleColors.has(r.color));

  return (
    <AppLayout>
      <div className="space-y-6 animate-fade-in">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground">Shop Recommendations</h1>
          <p className="text-muted-foreground">Curated picks based on your wardrobe, season & trends</p>
        </div>

        <div className="flex gap-2">
          {[
            { key: 'all', label: 'All Picks' },
            { key: 'season', label: `${season.charAt(0).toUpperCase() + season.slice(1)} Essentials` },
            { key: 'compatible', label: 'Color Match' },
          ].map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setFilter(key as any)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                filter === key ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((item, i) => (
            <div key={i} className="glass-card rounded-xl overflow-hidden hover:border-primary/30 transition-all group">
              <div className="w-full h-48 bg-secondary overflow-hidden">
                <img src={item.image} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" />
              </div>
              <div className="p-5">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="font-display text-lg font-semibold text-foreground">{item.name}</h3>
                    <p className="text-sm text-muted-foreground">{item.store}</p>
                  </div>
                  <span className="text-lg font-bold text-primary">{item.price}</span>
                </div>
                <div className="flex flex-wrap gap-1.5 mb-4">
                  {item.tags.map(tag => (
                    <span key={tag} className="px-2 py-0.5 rounded-full bg-secondary text-xs text-muted-foreground capitalize">{tag}</span>
                  ))}
                </div>
                <a href={item.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 text-sm text-primary hover:underline">
                  Shop now <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppLayout>
  );
};

export default Shop;
