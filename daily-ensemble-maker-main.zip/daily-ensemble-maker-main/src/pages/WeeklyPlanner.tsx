import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import AppLayout from '@/components/AppLayout';

type WardrobeItem = { id: string; name: string; type: string; color: string; };

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

const WeeklyPlanner = () => {
  const { user } = useAuth();
  const [items, setItems] = useState<WardrobeItem[]>([]);
  const [plans, setPlans] = useState<Record<string, string[]>>({});

  useEffect(() => {
    if (!user) return;
    const fetch = async () => {
      const { data } = await supabase
        .from('wardrobe_items')
        .select('id, name, type, color')
        .eq('user_id', user.id);
      setItems((data as WardrobeItem[]) ?? []);
    };
    fetch();
  }, [user]);

  useEffect(() => {
    if (items.length === 0) return;
    // Auto-generate weekly plan
    const tops = items.filter(i => ['top', 'dress'].includes(i.type));
    const bottoms = items.filter(i => i.type === 'bottom');
    const outerwear = items.filter(i => i.type === 'outerwear');

    const newPlans: Record<string, string[]> = {};
    DAYS.forEach((day, i) => {
      const dayItems: string[] = [];
      if (tops.length > 0) dayItems.push(tops[i % tops.length].name);
      if (bottoms.length > 0) dayItems.push(bottoms[i % bottoms.length].name);
      if (outerwear.length > 0 && (i === 0 || i === 4 || i === 6)) dayItems.push(outerwear[i % outerwear.length].name);
      newPlans[day] = dayItems;
    });
    setPlans(newPlans);
  }, [items]);

  const colorMap: Record<string, string> = {
    black: '#1a1a1a', white: '#f5f5f5', navy: '#1a2744', grey: '#808080', beige: '#d4b896',
    brown: '#6b4226', red: '#c0392b', blue: '#2980b9', green: '#27ae60', pink: '#e84393',
    yellow: '#f1c40f', orange: '#e67e22', purple: '#8e44ad',
  };

  return (
    <AppLayout>
      <div className="space-y-6 animate-fade-in">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground">Weekly Planner</h1>
          <p className="text-muted-foreground">Auto-generated outfit suggestions for each day</p>
        </div>

        {items.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground">
            <p className="font-display text-xl mb-2">Add clothes first</p>
            <p className="text-sm">Go to your wardrobe and add items to see weekly plans.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {DAYS.map((day, idx) => (
              <div key={day} className={`glass-card rounded-xl p-5 ${idx === 0 ? 'ring-1 ring-primary/30' : ''}`}>
                <h3 className="font-display text-lg font-semibold text-foreground mb-1">{day}</h3>
                {idx === 0 && <span className="text-[10px] uppercase tracking-widest text-primary font-semibold">Today</span>}
                <div className="mt-4 space-y-3">
                  {(plans[day] || []).map((itemName, i) => {
                    const item = items.find(it => it.name === itemName);
                    return (
                      <div key={i} className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-md" style={{ backgroundColor: colorMap[item?.color || 'grey'] || '#808080' }} />
                        <div>
                          <p className="text-sm font-medium text-foreground">{itemName}</p>
                          <p className="text-xs text-muted-foreground capitalize">{item?.type}</p>
                        </div>
                      </div>
                    );
                  })}
                  {(plans[day] || []).length === 0 && (
                    <p className="text-xs text-muted-foreground italic">No outfit planned</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default WeeklyPlanner;
