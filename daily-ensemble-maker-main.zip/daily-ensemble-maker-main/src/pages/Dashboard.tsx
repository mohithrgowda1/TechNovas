import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import AppLayout from '@/components/AppLayout';
import { Shirt, Calendar, BarChart3, ShoppingBag } from 'lucide-react';
import { Link } from 'react-router-dom';

const Dashboard = () => {
  const { user } = useAuth();
  const [wardrobeCount, setWardrobeCount] = useState(0);
  const [profileName, setProfileName] = useState('');

  useEffect(() => {
    if (!user) return;

    const fetchData = async () => {
      const { count } = await supabase
        .from('wardrobe_items')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id);
      setWardrobeCount(count ?? 0);

      const { data: profile } = await supabase
        .from('profiles')
        .select('name')
        .eq('user_id', user.id)
        .maybeSingle();
      setProfileName(profile?.name || user.email?.split('@')[0] || 'Fashionista');
    };

    fetchData();
  }, [user]);

  const quickLinks = [
    { to: '/wardrobe', label: 'My Wardrobe', description: 'Manage your clothing collection', icon: Shirt, count: `${wardrobeCount} items` },
    { to: '/planner', label: 'Weekly Planner', description: 'Plan outfits for the week', icon: Calendar, count: '7 days' },
    { to: '/compatibility', label: 'Compatibility', description: 'See outfit match scores', icon: BarChart3, count: 'Analyze' },
    { to: '/shop', label: 'Shop Picks', description: 'Curated recommendations', icon: ShoppingBag, count: 'Browse' },
  ];

  return (
    <AppLayout>
      <div className="space-y-8 animate-fade-in">
        <div>
          <h1 className="font-display text-4xl font-bold text-foreground mb-2">
            Hello, <span className="text-gradient-gold">{profileName}</span>
          </h1>
          <p className="text-muted-foreground">Welcome to your personal style studio.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {quickLinks.map(({ to, label, description, icon: Icon, count }) => (
            <Link
              key={to}
              to={to}
              className="glass-card rounded-xl p-6 hover:border-primary/30 transition-all duration-300 group"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <span className="text-xs text-muted-foreground font-medium">{count}</span>
              </div>
              <h3 className="font-display text-lg font-semibold text-foreground mb-1 group-hover:text-primary transition-colors">{label}</h3>
              <p className="text-sm text-muted-foreground">{description}</p>
            </Link>
          ))}
        </div>
      </div>
    </AppLayout>
  );
};

export default Dashboard;
