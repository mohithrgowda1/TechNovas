import { useEffect, useState, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import AppLayout from '@/components/AppLayout';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Camera, Upload, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

type WardrobeItem = { id: string; name: string; type: string; color: string; season: string; image_url: string | null; };

const colorCompatibility: Record<string, string[]> = {
  black: ['white', 'grey', 'beige', 'red', 'navy', 'pink', 'yellow'],
  white: ['black', 'navy', 'blue', 'grey', 'beige', 'red', 'green'],
  navy: ['white', 'beige', 'grey', 'brown', 'pink', 'yellow'],
  grey: ['black', 'white', 'navy', 'blue', 'pink', 'red'],
  beige: ['black', 'navy', 'brown', 'white', 'green', 'blue'],
  brown: ['beige', 'white', 'navy', 'green', 'orange'],
  red: ['black', 'white', 'grey', 'navy', 'beige'],
  blue: ['white', 'grey', 'beige', 'brown', 'navy'],
  green: ['white', 'beige', 'brown', 'navy', 'grey'],
  pink: ['black', 'white', 'grey', 'navy', 'beige'],
  yellow: ['black', 'navy', 'white', 'grey', 'blue'],
  orange: ['brown', 'navy', 'white', 'beige', 'black'],
  purple: ['white', 'grey', 'beige', 'black', 'pink'],
};

const getScore = (items: WardrobeItem[]) => {
  if (items.length < 2) return 100;
  let matches = 0;
  let total = 0;
  for (let i = 0; i < items.length; i++) {
    for (let j = i + 1; j < items.length; j++) {
      total++;
      const compat = colorCompatibility[items[i].color] || [];
      if (compat.includes(items[j].color)) matches++;
    }
  }
  return total === 0 ? 100 : Math.round((matches / total) * 100);
};

const Compatibility = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [items, setItems] = useState<WardrobeItem[]>([]);
  const [selectedItems, setSelectedItems] = useState<WardrobeItem[]>([]);
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!user) return;
    const fetchData = async () => {
      const { data } = await supabase
        .from('wardrobe_items')
        .select('id, name, type, color, season, image_url')
        .eq('user_id', user.id);
      setItems((data as WardrobeItem[]) ?? []);
    };
    fetchData();
  }, [user]);

  const tops = items.filter(i => ['top', 'dress'].includes(i.type));
  const bottoms = items.filter(i => i.type === 'bottom');

  const outfitPairs = tops.flatMap(top =>
    bottoms.map(bottom => ({
      top,
      bottom,
      score: getScore([top, bottom]),
    }))
  ).sort((a, b) => b.score - a.score);

  const overallScore = items.length > 1 ? getScore(items) : 0;

  const toggleSelect = (item: WardrobeItem) => {
    setSelectedItems(prev =>
      prev.find(i => i.id === item.id)
        ? prev.filter(i => i.id !== item.id)
        : [...prev, item]
    );
  };

  const selectedScore = selectedItems.length >= 2 ? getScore(selectedItems) : null;

  const handlePhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => setPhotoPreview(reader.result as string);
    reader.readAsDataURL(file);
    toast({ title: 'Photo added!', description: 'Now select wardrobe items to check compatibility against your outfit photo.' });
  };

  const colorMap: Record<string, string> = {
    black: '#1a1a1a', white: '#f5f5f5', navy: '#1a2744', grey: '#808080', beige: '#d4b896',
    brown: '#6b4226', red: '#c0392b', blue: '#2980b9', green: '#27ae60', pink: '#e84393',
    yellow: '#f1c40f', orange: '#e67e22', purple: '#8e44ad',
  };

  return (
    <AppLayout>
      <div className="space-y-8 animate-fade-in">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground">Compatibility</h1>
          <p className="text-muted-foreground">How well your clothes work together</p>
        </div>

        {/* Photo check section */}
        <div className="glass-card rounded-xl p-6">
          <h2 className="font-display text-xl font-semibold text-foreground mb-4">📸 Check Your Outfit</h2>
          <p className="text-sm text-muted-foreground mb-4">Take a photo of your outfit or select items from your wardrobe to check compatibility.</p>

          <div className="flex flex-col md:flex-row gap-6">
            {/* Photo upload */}
            <div className="flex-shrink-0">
              <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handlePhotoSelect} />
              <input ref={cameraInputRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={handlePhotoSelect} />
              {photoPreview ? (
                <div className="relative w-48 h-48 rounded-lg overflow-hidden">
                  <img src={photoPreview} alt="Your outfit" className="w-full h-full object-cover" />
                  <button
                    onClick={() => setPhotoPreview(null)}
                    className="absolute top-2 right-2 p-1.5 rounded-full bg-destructive/80 text-destructive-foreground"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ) : (
                <div className="flex flex-col gap-2">
                  <Button variant="outline" onClick={() => cameraInputRef.current?.click()}>
                    <Camera className="w-4 h-4 mr-2" /> Take Photo
                  </Button>
                  <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
                    <Upload className="w-4 h-4 mr-2" /> Upload Photo
                  </Button>
                </div>
              )}
            </div>

            {/* Item selection */}
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground mb-2">Select items to compare ({selectedItems.length} selected)</p>
              <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto">
                {items.map(item => {
                  const isSelected = selectedItems.find(i => i.id === item.id);
                  return (
                    <button
                      key={item.id}
                      onClick={() => toggleSelect(item)}
                      className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-all border ${
                        isSelected
                          ? 'border-primary bg-primary/10 text-foreground'
                          : 'border-border bg-secondary text-muted-foreground hover:text-foreground'
                      }`}
                    >
                      {item.image_url ? (
                        <img src={item.image_url} alt={item.name} className="w-6 h-6 rounded object-cover" />
                      ) : (
                        <div className="w-6 h-6 rounded" style={{ backgroundColor: colorMap[item.color] || '#808080' }} />
                      )}
                      <span className="truncate max-w-[100px]">{item.name}</span>
                    </button>
                  );
                })}
              </div>

              {/* Score display */}
              {selectedScore !== null && (
                <div className="mt-4 p-4 rounded-lg bg-secondary">
                  <div className="flex items-center gap-3">
                    <span className={`text-3xl font-bold font-display ${selectedScore >= 80 ? 'text-green-400' : selectedScore >= 50 ? 'text-primary' : 'text-destructive'}`}>
                      {selectedScore}%
                    </span>
                    <div className="flex-1">
                      <Progress value={selectedScore} className="h-2" />
                      <p className="text-xs text-muted-foreground mt-1">
                        {selectedScore >= 80 ? 'Great match!' : selectedScore >= 50 ? 'Decent combination.' : 'Consider different pairings.'}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Overall score */}
        <div className="glass-card rounded-xl p-8 text-center">
          <p className="text-sm text-muted-foreground uppercase tracking-widest mb-2">Overall Wardrobe Score</p>
          <p className="font-display text-6xl font-bold text-gradient-gold">{overallScore}%</p>
          <Progress value={overallScore} className="mt-4 max-w-xs mx-auto h-2" />
          <p className="text-sm text-muted-foreground mt-3">
            {overallScore >= 80 ? 'Excellent color harmony!' : overallScore >= 50 ? 'Good versatility in your wardrobe.' : 'Consider adding neutral pieces for better matching.'}
          </p>
        </div>

        {/* Outfit pairs */}
        {outfitPairs.length > 0 && (
          <div>
            <h2 className="font-display text-xl font-semibold text-foreground mb-4">Top + Bottom Combinations</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {outfitPairs.slice(0, 8).map(({ top, bottom, score }, i) => (
                <div key={i} className="glass-card rounded-xl p-4 flex items-center gap-4">
                  <div className="flex gap-2">
                    {top.image_url ? (
                      <img src={top.image_url} alt={top.name} className="w-10 h-10 rounded-md object-cover" />
                    ) : (
                      <div className="w-10 h-10 rounded-md" style={{ backgroundColor: colorMap[top.color] || '#808080' }} />
                    )}
                    {bottom.image_url ? (
                      <img src={bottom.image_url} alt={bottom.name} className="w-10 h-10 rounded-md object-cover" />
                    ) : (
                      <div className="w-10 h-10 rounded-md" style={{ backgroundColor: colorMap[bottom.color] || '#808080' }} />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{top.name} + {bottom.name}</p>
                    <p className="text-xs text-muted-foreground capitalize">{top.color} & {bottom.color}</p>
                  </div>
                  <div className={`text-sm font-bold ${score >= 80 ? 'text-green-400' : score >= 50 ? 'text-primary' : 'text-destructive'}`}>
                    {score}%
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {items.length < 2 && (
          <div className="text-center py-16 text-muted-foreground">
            <p className="font-display text-xl mb-2">Not enough items</p>
            <p className="text-sm">Add at least 2 items (tops and bottoms) to see compatibility scores.</p>
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default Compatibility;
