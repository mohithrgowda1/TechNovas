import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import AppLayout from '@/components/AppLayout';
import { ExternalLink, Percent, Tag } from 'lucide-react';

type WardrobeItem = { id: string; color: string; type: string; };

const colorCompat: Record<string, string[]> = {
  black: ['white', 'grey', 'beige', 'red', 'navy'],
  white: ['black', 'navy', 'blue', 'grey', 'beige'],
  navy: ['white', 'beige', 'grey', 'brown', 'pink'],
  grey: ['black', 'white', 'navy', 'blue', 'pink'],
  beige: ['black', 'navy', 'brown', 'white', 'green'],
  brown: ['beige', 'white', 'navy', 'green'],
  red: ['black', 'white', 'grey', 'navy'],
  blue: ['white', 'grey', 'beige', 'brown'],
  green: ['white', 'beige', 'brown', 'navy'],
  pink: ['black', 'white', 'grey', 'navy'],
  yellow: ['black', 'navy', 'white'],
  orange: ['brown', 'navy', 'white'],
  purple: ['white', 'grey', 'beige'],
};

const deals = [
  { name: 'Slim Fit Chinos', type: 'bottom', color: 'beige', originalPrice: '$60', salePrice: '$35', discount: '42%', store: 'H&M', url: 'https://www.hm.com', gender: 'unisex', image: 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=300&h=300&fit=crop', tags: ['classic', 'versatile'] },
  { name: 'Oversized Blazer', type: 'formal', color: 'black', originalPrice: '$120', salePrice: '$72', discount: '40%', store: 'Zara', url: 'https://www.zara.com', gender: 'women', image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=300&h=300&fit=crop', tags: ['formal', 'office'] },
  { name: 'Wool Blend Coat', type: 'outerwear', color: 'grey', originalPrice: '$200', salePrice: '$120', discount: '40%', store: 'COS', url: 'https://www.cos.com', gender: 'unisex', image: 'https://images.unsplash.com/photo-1539533018447-63fcce2678e3?w=300&h=300&fit=crop', tags: ['winter', 'premium'] },
  { name: 'Cotton Polo', type: 'top', color: 'navy', originalPrice: '$45', salePrice: '$25', discount: '44%', store: 'Ralph Lauren', url: 'https://www.ralphlauren.com', gender: 'men', image: 'https://images.unsplash.com/photo-1625910513413-5fc42fc19182?w=300&h=300&fit=crop', tags: ['casual', 'classic'] },
  { name: 'Pleated Midi Skirt', type: 'bottom', color: 'beige', originalPrice: '$65', salePrice: '$39', discount: '40%', store: 'Mango', url: 'https://www.mango.com', gender: 'women', image: 'https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?w=300&h=300&fit=crop', tags: ['elegant', 'feminine'] },
  { name: 'Leather Belt', type: 'accessory', color: 'brown', originalPrice: '$40', salePrice: '$22', discount: '45%', store: 'Massimo Dutti', url: 'https://www.massimodutti.com', gender: 'unisex', image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=300&h=300&fit=crop', tags: ['accessory', 'essential'] },
  { name: 'White Sneakers', type: 'shoes', color: 'white', originalPrice: '$90', salePrice: '$54', discount: '40%', store: 'Adidas', url: 'https://www.adidas.com', gender: 'unisex', image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=300&h=300&fit=crop', tags: ['casual', 'everyday'] },
  { name: 'Silk Tie', type: 'accessory', color: 'navy', originalPrice: '$55', salePrice: '$30', discount: '45%', store: 'Hugo Boss', url: 'https://www.hugoboss.com', gender: 'men', image: 'https://images.unsplash.com/photo-1589756823695-278bc923a206?w=300&h=300&fit=crop', tags: ['formal', 'accessory'] },
  { name: 'Statement Necklace', type: 'accessory', color: 'gold', originalPrice: '$35', salePrice: '$18', discount: '49%', store: 'ASOS', url: 'https://www.asos.com', gender: 'women', image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=300&h=300&fit=crop', tags: ['accessory', 'trendy'] },
  { name: 'Formal Shirt', type: 'formal', color: 'white', originalPrice: '$70', salePrice: '$42', discount: '40%', store: 'Charles Tyrwhitt', url: 'https://www.charlestyrwhitt.com', gender: 'men', image: 'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=300&h=300&fit=crop', tags: ['formal', 'office'] },
];

const Deals = () => {
  const { user } = useAuth();
  const [wardrobeItems, setWardrobeItems] = useState<WardrobeItem[]>([]);
  const [filter, setFilter] = useState<'all' | 'matching'>('all');
  const [gender, setGender] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;
    const fetchData = async () => {
      const { data: items } = await supabase.from('wardrobe_items').select('id, color, type').eq('user_id', user.id);
      setWardrobeItems((items as WardrobeItem[]) ?? []);
      const { data: profile } = await supabase.from('profiles').select('gender').eq('user_id', user.id).maybeSingle();
      setGender(profile?.gender || null);
    };
    fetchData();
  }, [user]);

  const userColors = [...new Set(wardrobeItems.map(i => i.color))];
  const compatibleColors = new Set(userColors.flatMap(c => colorCompat[c] || []));

  let filtered = deals;
  // Filter by gender
  if (gender && gender !== 'unisex') {
    filtered = filtered.filter(d => d.gender === gender || d.gender === 'unisex');
  }
  if (filter === 'matching') {
    filtered = filtered.filter(d => compatibleColors.has(d.color));
  }

  return (
    <AppLayout>
      <div className="space-y-6 animate-fade-in">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground flex items-center gap-2">
            <Percent className="w-7 h-7 text-primary" /> Deals & Discounts
          </h1>
          <p className="text-muted-foreground">Hot deals on clothes that match your wardrobe</p>
        </div>

        <div className="flex gap-2">
          {[
            { key: 'all', label: 'All Deals' },
            { key: 'matching', label: 'Matches My Wardrobe' },
          ].map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setFilter(key as any)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                filter === key ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((item, i) => (
            <div key={i} className="glass-card rounded-xl overflow-hidden hover:border-primary/30 transition-all group">
              <div className="w-full h-48 bg-secondary overflow-hidden">
                <img src={item.image} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" loading="lazy" />
              </div>
              <div className="p-5">
                <div className="flex items-center gap-2 mb-2">
                  <span className="px-2 py-0.5 rounded-full bg-destructive/20 text-destructive text-xs font-bold">{item.discount} OFF</span>
                  <Tag className="w-3 h-3 text-muted-foreground" />
                </div>
                <h3 className="font-display text-lg font-semibold text-foreground mb-1">{item.name}</h3>
                <p className="text-sm text-muted-foreground mb-2">{item.store}</p>
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-lg font-bold text-primary">{item.salePrice}</span>
                  <span className="text-sm text-muted-foreground line-through">{item.originalPrice}</span>
                </div>
                <div className="flex flex-wrap gap-1.5 mb-4">
                  {item.tags.map(tag => (
                    <span key={tag} className="px-2 py-0.5 rounded-full bg-secondary text-xs text-muted-foreground capitalize">{tag}</span>
                  ))}
                </div>
                <a href={item.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 text-sm text-primary hover:underline">
                  Shop now <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16 text-muted-foreground">
            <p className="font-display text-xl mb-2">No matching deals</p>
            <p className="text-sm">Add more items to your wardrobe to discover matching deals.</p>
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default Deals;
