import { useEffect, useState, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import AppLayout from '@/components/AppLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Trash2, Camera, Upload } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

type WardrobeItem = {
  id: string;
  name: string;
  type: string;
  color: string;
  season: string;
  brand: string | null;
  image_url: string | null;
};

const TYPES_MEN = ['top', 'bottom', 'formal', 'outerwear', 'shoes', 'accessory'];
const TYPES_WOMEN = ['top', 'bottom', 'dress', 'formal', 'outerwear', 'shoes', 'accessory'];
const TYPES_DEFAULT = ['top', 'bottom', 'dress', 'formal', 'outerwear', 'shoes', 'accessory'];
const SEASONS = ['all', 'spring', 'summer', 'fall', 'winter'];
const COLORS = ['black', 'white', 'navy', 'grey', 'beige', 'brown', 'red', 'blue', 'green', 'pink', 'yellow', 'orange', 'purple'];

const Wardrobe = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [items, setItems] = useState<WardrobeItem[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: '', type: 'top', color: 'black', season: 'all', brand: '' });
  const [filter, setFilter] = useState('all');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [gender, setGender] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const TYPES = gender === 'men' ? TYPES_MEN : gender === 'women' ? TYPES_WOMEN : TYPES_DEFAULT;

  const fetchItems = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('wardrobe_items')
      .select('id, name, type, color, season, brand, image_url')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });
    setItems((data as WardrobeItem[]) ?? []);
  };

  useEffect(() => {
    if (!user) return;
    fetchItems();
    // Fetch gender
    supabase.from('profiles').select('gender').eq('user_id', user.id).maybeSingle().then(({ data }) => {
      setGender(data?.gender || null);
    });
  }, [user]);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: 'File too large', description: 'Please select an image under 5MB.', variant: 'destructive' });
      return;
    }
    setImageFile(file);
    const reader = new FileReader();
    reader.onloadend = () => setImagePreview(reader.result as string);
    reader.readAsDataURL(file);
  };

  const uploadImage = async (file: File): Promise<string | null> => {
    if (!user) return null;
    const ext = file.name.split('.').pop();
    const path = `${user.id}/${crypto.randomUUID()}.${ext}`;
    const { error } = await supabase.storage.from('wardrobe-images').upload(path, file);
    if (error) {
      toast({ title: 'Upload failed', description: error.message, variant: 'destructive' });
      return null;
    }
    const { data: urlData } = supabase.storage.from('wardrobe-images').getPublicUrl(path);
    return urlData.publicUrl;
  };

  const addItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    if (!imageFile) {
      toast({ title: 'Photo required', description: 'Please take or upload a photo of your clothing item.', variant: 'destructive' });
      return;
    }

    setUploading(true);
    const imageUrl = await uploadImage(imageFile);

    const { error } = await supabase.from('wardrobe_items').insert({
      user_id: user.id,
      name: form.name,
      type: form.type,
      color: form.color,
      season: form.season,
      brand: form.brand || null,
      image_url: imageUrl,
    });
    if (error) toast({ title: 'Error', description: error.message, variant: 'destructive' });
    else {
      toast({ title: 'Added!', description: `${form.name} added to your wardrobe.` });
      setForm({ name: '', type: 'top', color: 'black', season: 'all', brand: '' });
      setImageFile(null);
      setImagePreview(null);
      setOpen(false);
      fetchItems();
    }
    setUploading(false);
  };

  const deleteItem = async (id: string) => {
    await supabase.from('wardrobe_items').delete().eq('id', id);
    fetchItems();
  };

  const filtered = filter === 'all' ? items : items.filter(i => i.type === filter);

  const colorMap: Record<string, string> = {
    black: '#1a1a1a', white: '#f5f5f5', navy: '#1a2744', grey: '#808080', beige: '#d4b896',
    brown: '#6b4226', red: '#c0392b', blue: '#2980b9', green: '#27ae60', pink: '#e84393',
    yellow: '#f1c40f', orange: '#e67e22', purple: '#8e44ad',
  };

  return (
    <AppLayout>
      <div className="space-y-6 animate-fade-in">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl font-bold text-foreground">My Wardrobe</h1>
            <p className="text-muted-foreground">{items.length} pieces in your collection</p>
          </div>
          <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) { setImageFile(null); setImagePreview(null); } }}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-gold text-primary-foreground shadow-gold">
                <Plus className="w-4 h-4 mr-2" /> Add Item
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="font-display text-xl">Add Clothing</DialogTitle>
              </DialogHeader>
              <form onSubmit={addItem} className="space-y-4">
                {/* Photo upload - required */}
                <div className="space-y-2">
                  <Label>Photo <span className="text-destructive">*</span></Label>
                  {imagePreview ? (
                    <div className="relative w-full aspect-square rounded-lg overflow-hidden bg-secondary">
                      <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => { setImageFile(null); setImagePreview(null); }}
                        className="absolute top-2 right-2 p-1.5 rounded-full bg-destructive/80 text-destructive-foreground"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleImageSelect} />
                      <input ref={cameraInputRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={handleImageSelect} />
                      <Button type="button" variant="outline" className="flex-1" onClick={() => cameraInputRef.current?.click()}>
                        <Camera className="w-4 h-4 mr-2" /> Take Photo
                      </Button>
                      <Button type="button" variant="outline" className="flex-1" onClick={() => fileInputRef.current?.click()}>
                        <Upload className="w-4 h-4 mr-2" /> Upload
                      </Button>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label>Name</Label>
                  <Input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="e.g. Blue Oxford Shirt" className="bg-secondary" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Type</Label>
                    <Select value={form.type} onValueChange={v => setForm({ ...form, type: v })}>
                      <SelectTrigger className="bg-secondary"><SelectValue /></SelectTrigger>
                      <SelectContent>{TYPES.map(t => <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Color</Label>
                    <Select value={form.color} onValueChange={v => setForm({ ...form, color: v })}>
                      <SelectTrigger className="bg-secondary"><SelectValue /></SelectTrigger>
                      <SelectContent>{COLORS.map(c => <SelectItem key={c} value={c} className="capitalize">{c}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Season</Label>
                    <Select value={form.season} onValueChange={v => setForm({ ...form, season: v })}>
                      <SelectTrigger className="bg-secondary"><SelectValue /></SelectTrigger>
                      <SelectContent>{SEASONS.map(s => <SelectItem key={s} value={s} className="capitalize">{s}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Brand (optional)</Label>
                    <Input value={form.brand} onChange={e => setForm({ ...form, brand: e.target.value })} placeholder="e.g. Zara" className="bg-secondary" />
                  </div>
                </div>
                <Button type="submit" className="w-full bg-gradient-gold text-primary-foreground" disabled={uploading}>
                  {uploading ? 'Uploading...' : 'Add to Wardrobe'}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Filter tabs */}
        <div className="flex gap-2 flex-wrap">
          {['all', ...TYPES].map(t => (
            <button
              key={t}
              onClick={() => setFilter(t)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors capitalize ${
                filter === t ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground hover:text-foreground'
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        {/* Items grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filtered.map(item => (
            <div key={item.id} className="glass-card rounded-xl p-4 group hover:border-primary/30 transition-all">
              <div className="w-full aspect-square rounded-lg bg-secondary flex items-center justify-center mb-3 relative overflow-hidden">
                {item.image_url ? (
                  <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-16 h-16 rounded-full" style={{ backgroundColor: colorMap[item.color] || '#808080' }} />
                )}
                <button
                  onClick={() => deleteItem(item.id)}
                  className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-full bg-destructive/80 text-destructive-foreground"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
              <h4 className="font-medium text-foreground text-sm truncate">{item.name}</h4>
              <p className="text-xs text-muted-foreground capitalize">{item.type} · {item.color} · {item.season}</p>
              {item.brand && <p className="text-xs text-primary mt-1">{item.brand}</p>}
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16 text-muted-foreground">
            <p className="font-display text-xl mb-2">Your wardrobe is empty</p>
            <p className="text-sm">Add your first piece to get started!</p>
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default Wardrobe;
