
-- Add profile fields for skin tone, age, clothing size, gender
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS gender text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS age integer DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS clothing_size text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS skin_tone text DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS skin_tone_photo_url text DEFAULT NULL;
